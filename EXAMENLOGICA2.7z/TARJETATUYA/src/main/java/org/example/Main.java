package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner= new Scanner(System.in);

        String nombre;
        String apellidos;
        int edad;
        int usosTarjeta;
        int puntajeCredito;
        double comprasAseo;
        double comprasAlimenticios;
        double otrosProductos;

        // Solicitar datos del usuario
        System.out.print("Ingrese su nombre: ");
        nombre = scanner.nextLine();

        System.out.print("Ingrese sus apellidos: ");
        apellidos = scanner.nextLine();

        System.out.print("Ingrese su edad: ");
        edad = scanner.nextInt();

        System.out.print("Ingrese el número de usos de la tarjeta durante el último mes: ");
        usosTarjeta = scanner.nextInt();

        System.out.print("Ingrese el monto de compras de productos de aseo (en pesos): ");
        comprasAseo = scanner.nextDouble();

        System.out.print("Ingrese el monto de compras de productos alimenticios (en pesos): ");
        comprasAlimenticios = scanner.nextDouble();

        System.out.print("Ingrese el monto de otros productos comprados (en pesos): ");
        otrosProductos = scanner.nextDouble();

        System.out.print("Ingrese su puntaje de crédito (1-9): ");
        puntajeCredito = scanner.nextInt();

        // Calcular la deuda total
        double deudaTotal = comprasAseo + comprasAlimenticios + otrosProductos;
        double auxilio = 0;

        // Aplicar el auxilio basado en el puntaje
        switch (puntajeCredito) {
            case 1:
                auxilio = deudaTotal * 0.25;
                break;
            case 2:
                auxilio = deudaTotal * 0.20;
                break;
            case 3:
                auxilio = deudaTotal * 0.15;
                break;
            case 4:
                auxilio = deudaTotal * 0.10;
                break;
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
                auxilio = 0;
                break;
            default:
                System.out.println("Puntaje de crédito no válido.");
                return;
        }

        System.out.println("Información del usuario:");
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellidos: " + apellidos);
        System.out.println("Edad: " + edad);
        System.out.println("Usos de la tarjeta en el último mes: " + usosTarjeta);
        System.out.printf("Monto total de la deuda: $%.2f\n", deudaTotal);
        System.out.printf("Auxilio aplicado: $%.2f\n", auxilio);
        System.out.printf("Deuda total después del auxilio: $%.2f\n", deudaTotal - auxilio);

        //printf= doubles - $%.2f para que el dato salga con signo de peso($) para que funcione con el printf (%) el (.)
        //para que sea un decimal y la (f) para que funcione como un float y el \n para que de un salto de linea en los datos

    }
}