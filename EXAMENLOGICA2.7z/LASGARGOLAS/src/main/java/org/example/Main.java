package org.example;

import java.time.LocalDate;
import java.time.Period;
import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String cedula;
        int edad;
        String nombre;
        String apellido;
        String Ciudad;

        //Pedir datos

        System.out.print("Introduce tu cedula : ");
        cedula = scanner.nextLine();

        System.out.print("Introduce tu Nombre  ");
        nombre = scanner.nextLine();

        System.out.print("y tu apellido: ");
        apellido = scanner.nextLine();

        System.out.print("Introduce tu edad: ");
        edad = scanner.nextInt();

        System.out.print("Introduce tu ciudad: ");


        if (edad < 18) {
            System.out.print("NO PUEDE COMPRAR BOLETAS, COMO DIJO HETO Y VITO CHAO BAMBINO");
        } else {
            scanner.nextLine();
            System.out.print("Ingrese la ciudad del comprador: ");
            String ciudad = scanner.nextLine();

            System.out.print("Ingrese el numero de boletas que desea comprar (4 Max): ");
            int numeroBoletas = scanner.nextInt();

            if (numeroBoletas <= 0) {
                System.out.print("El numero de boletas debe ser mayor a 0. ");
            } else if (numeroBoletas > 4) {
                System.out.print("No puede comprar mas de 4 boletas.");
            } else {
                int costoIndividual = 450000;
                int costoTotal = numeroBoletas * costoIndividual;

                System.out.println("Resumen de la compra:");
                System.out.println("**********************");
                System.out.println("Nombre: " + nombre + apellido);
                System.out.println("Edad: " + edad);
                System.out.println("Ciudad: " + ciudad);
                System.out.println("Numero de boletas: " + numeroBoletas);
                System.out.println("Costo total: $" + costoTotal);

            }
        }
    }
}